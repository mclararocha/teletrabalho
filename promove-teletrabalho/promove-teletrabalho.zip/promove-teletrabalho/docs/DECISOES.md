# Decisões de projeto

Registro das escolhas tomadas na construção das telas, com o motivo. Serve para não
refazer discussão já vencida e para a empresa desenvolvedora entender o porquê.

## Cálculo

- A nota é apurada por atividade, agregada por entrega e depois pelo mês.
- O InCp é da atividade, não da entrega.
- Zero em qualquer um dos três índices zera a nota da entrega inteira.
- As faixas de prazo e de quantidade são as das Tabelas 4 e 5 do Anexo II.
- O prazo é apurado em horas úteis dentro da jornada cadastrada do servidor, de segunda
  a sexta. Feriados ainda não são descontados no protótipo.

## Jornada

- Só cargas de 8 ou 6 horas diárias.
- Intervalo mínimo de 1 hora entre turnos; a carga de 8 horas exige dois turnos.
- Os horários de pactuação e de conclusão ficam limitados às janelas da jornada, em
  intervalos de 30 minutos.
- A jornada precisa ser dado cadastral do servidor, congelado na pactuação. Alterá-la na
  avaliação muda o resultado sem que nada tenha mudado no trabalho.

## Pactuação

- Tela única, operada por servidor e chefia, com visões distintas.
- Campos editados diretamente, sem botão de "ajustar".
- Excluir item do plano é ação da chefia; enquanto em rascunho, o servidor exclui o que
  ele próprio incluiu.
- O aceite é do plano inteiro, no rodapé. A discordância é registrada no item alterado.
- Item já validado fica somente leitura nas duas visões; alterá-lo exige repactuação.

## Vagas e prioridade

- O limite alcança o órgão como um todo, e a autorização é por unidade. São condições
  distintas: unidade autorizada sem mapeamento validado continua inapta.
- A ordem de prioridade é única para a Pasta, porque o limite é do órgão.

## Painéis

- O painel setorial exibe agregados por unidade; a lista nominal fica no detalhamento.
- O painel central não traz nota média como indicador de topo: é média de médias
  calculada com escalas calibradas por chefias diferentes, e no topo viraria ranking.

## Pendências normativas identificadas

- Remissões a "art. XX" nos arts. 27, II e 38 da minuta.
- O art. 41 aponta o limite para o § 5º do art. 6º, mas ele está no art. 7º.
- Dois artigos numerados 36; o art. 27 salta do inciso IV para o VI.
- Incisos II e III repetidos no art. 10, § 1º.
- O Sistema PROMOVE é citado como instituído no art. 3º, que trata de objetivos.
- O Capítulo X é intitulado "Da avaliação global dos resultados", mas seu único artigo
  trata do mapeamento das entregas.
