# PROMOVE – Teletrabalho · protótipo de telas

Protótipo navegável do módulo de teletrabalho do Sistema PROMOVE, do Poder Executivo do
Estado de Goiás. Reúne as telas dos perfis servidor, chefia imediata, titular de unidade,
unidade setorial e órgão central, além da calculadora que demonstra o cálculo da nota.

Serve para validar regras com a área técnica e para especificar o sistema à empresa
desenvolvedora. Não é software de produção.

## Como abrir

Não há build nem dependência. Abra `index.html` no navegador, ou publique o repositório
no GitHub Pages e acesse pela URL gerada.

## Telas

| Nº | Tela | Perfil |
|----|------|--------|
| 07 | Plano de trabalho do servidor | Servidor |
| 08 | Verificação dos resultados | Chefia imediata |
| 09 | Pactuação do plano de trabalho | Servidor e chefia |
| 10 | Mapeamento de entregas e atividades | Titular da unidade |
| 11 | Painel da unidade setorial | Unidade setorial |
| 12 | Painel do órgão central | Órgão central |
| 13 | Ordem apurada do órgão | Unidade setorial |
| 14 | Desligamentos da unidade | Unidade setorial |
| 15 | Requerimento de adesão | Servidor e chefia |
| 16 | Cálculo da nota da atividade | Demonstração |

## Estrutura

```
index.html              hub de navegação
telas/                  uma tela por arquivo
assets/css/promove.css  folha compartilhada
docs/                   minuta e decisões de projeto
CLAUDE.md               regras permanentes para o assistente
INSTRUCOES.md           fila de tarefas
```

## Convenções

Português do Brasil em tudo. Nomes de arquivo em minúsculas, sem acento, com hífen.
Versionamento pelo Git, sem sufixos `-v2` no nome dos arquivos. Cores e espaçamentos
vêm das variáveis de `promove.css`.

## Referência normativa

Minuta de decreto do regime de teletrabalho, com aplicação supletiva do
Decreto nº 10.802/2025. A cópia de trabalho fica em `docs/`.
